padre(juan, carlos).
padre(juan, luis).
padre(carlos, daniel).
padre(carlos, diego).
padre(luis, pablo).
padre(luis, manuel).
padre(luis, ramiro).
abuelo(X,Y) :- padre(X,Z), padre(Z,Y).



%  i. Cuál el resultado de la consulta abuelo(X, manuel)? Juan 

%  ii. A partir del predicado binario padre, definir en Prolog los predicados binarios: hijo, hermano y descendiente.

% hijo
hijo(X, Y) :- padre(Y, X).

% hermano
hermano(X, Y) :-  padre(Z, X), padre(Z, Y), X \= Y.

% descendiente

%  iii. Dibujar el árbol de búsqueda de Prolog para la consulta descendiente(Alguien, juan).
%  iv. ¾Qué consulta habría que hacer para encontrar a los nietos de juan?
%  v. Cómo se puede definir una consulta para conocer a todos los hermanos de pablo?
%  vi. Considerar el agregado del siguiente hecho y regla:
%  ancestro(X, X).
%  ancestro(X, Y) :- ancestro(Z, Y), padre(X, Z).
%  y la base de conocimiento del ítem anterior.
%  vii. Explicar la respuesta a la consulta ancestro(juan, X). ¾Qué sucede si se pide más de un resultado?
%  viii. Sugerir una solución al problema hallado en los puntos anteriores reescribiendo el programa de ancestro.