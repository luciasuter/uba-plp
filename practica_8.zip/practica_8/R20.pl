desde2(X, X). % aca la Y va a unificar con X 
desde2(X, Y):- not(var(Y)), Y > X.
desde2(X, Y):- var(Y), X1 is X+1, desde2(X1, Y). % Y aca logro la recursion


% Numero poderoso: m tal que por cada divisor primo p que tiene m p² tambien es divisor.
% proximoNumPoderoso(X, Y) dar el siguiente poderoso a partir de X.

% proximoNumPoderoso(X, Y):- X1 is X+1, desde2(X1, Y), esPoderoso(Y). 

esDivisor(Y, K):- 0 is mod(Y, K).

esPrimo(K):- K>1, K1 is K-1, not((between(2, K1, M), 0 is mod(K, M))).

esPoderoso(Y):- not(hayDivisorPrimoQueNoCumple(Y)).

hayDivisorPrimoQueNoCumple(Y):- Y1 is Y-1, between(2, Y1, K), esDivisor(Y, K), esPrimo(K), K2 is K*K, not(esDivisor(Y, K2)).

