% CorteMasParejo
% corteMásParejo([1,2,3,4,2],L1,L2). →L1 = [1, 2, 3], L2 = [4, 2] ; false.
% corteMásParejo([1,2,1],L1,L2). →L1 = [1], L2 = [2, 1] ; L1 = [1, 2], L2 = [1] ; false. (son sublistas no permutaciones)
corteMasParejo([], [], []).
corteMasParejo(L, L1, L2):- append(L1, L2, L), sumlist(L1, S1), sumlist(L2, S2), abs((S2-S1), A), 
                            not((append(L3, L4, L), sumlist(L3, S3), sumlist(L4, S4), abs((S3-S4), A2), A2 < A)).