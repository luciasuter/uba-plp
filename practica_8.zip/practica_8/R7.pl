% i. a.intersección(+L1, +L2, -L3), tal que L3 es la intersección sin repeticiones de las listas L1 y L2, 
% respetando en L3 el orden en que aparecen los elementos en L1.

% 1 2 3 
% 2 5 3 4 = 1 2 3 5 4 
%interseccion([1,2,3], [2,5,3,4], ?)
interseccion(L1, [], L1).
interseccion(L1, [X|XS], L3):- member(X, L1), interseccion(L1, XS, L3).
interseccion(L1, [X|XS], LL):- not(member(X, L1)), interseccion(L1, XS, L3), append(L3, [X], LL).

%    b.partir(N, L, L1, L2), donde L1 tiene los N primeros elementos de L, y L2 el resto. Si L tiene menos de N elementos
% el predicado debe fallar. ¾Cuán reversible es este predicado? Es decir, ¾qué parámetros pueden estar indenidos al momento de la invocación?


partir(0, XS, [], XS).
partir(N, [X|XS], [X|L1], L4):- N>0, N2 is N-1, partir(N2, XS, L1, L4). 
% partir(N, L, L1, L2) No es reversible en el parametro N pero si en L1 y L2
% es porque no puede reescribir N?

% ii. borrar(+ListaOriginal, +X, -ListaSinXs), que elimina todas las ocurrencias de X de la lista ListaOriginal.

borrar([], _, []).
borrar([Y|YS], X, [Y|ZS]):- Y \= X, borrar(YS, X, ZS).
borrar([X|YS], X, ZS):- borrar(YS, X, ZS).

% iii. sacarDuplicados(+L1, -L2), que saca todos los elementos duplicados de la lista L1.
sacarDuplicados([], []).
sacarDuplicados([X|XS], [X|YS]):- borrar(XS, X, Z), sacarDuplicados(Z, YS).
% iv. permutación(+L1, ?L2), que tiene éxito cuando L2 es permutación de L1. ¾Hay una manera más eciente de denir este 
% predicado para cuando L2 está instanciada?
% v. reparto(+L, +N, -LListas) que tenga éxito si LListas es una lista de N listas (N ≥ 1) de cualquier longitud - incluso vacías - 
% tales que al concatenarlas se obtiene la lista L.

sublista(_, []).
sublista(L, SL) :-
	append(_, SLYAlgoMas, L),
	append(SL, _, SLYAlgoMas),
	SL \= [].

repartoAux(L, 0, []).
repartoAux(L, N, [LL|LLS]):-  sublista(L, LL), N1 is N-1, length(LLS, N1), repartoAux(L, N1, LLS). 
reparto(L, N, Y):- repartoAux(L, N, Y), flatten(Y, L).

% NO ES EFICIENTE... PORQUE ESTOY USANDO GENERATE AND TEST. COMO PUEDO HACERLO MEJOR?

% vi. repartoSinVacías(+L, -LListas) similar al anterior, pero ninguna de las listas de LListas puede ser vacía, y la 
% longitud de LListas puede variar.

repartoSinVacias(L, LLS):- length(L, X), between(1, X, Y), reparto(L, Y, LLS).
% la linea sublista(_, []). (34) define si hay o no listas vacias. En el ejercicio de reparto las necesito
% en este no. Como dependo de reparto para que funcione este ejercicio lo mejor seria tener otro reparto para este caso particular
% de todas formas este ej sigue siendo poco eficiente xq hago generate and test para algo que no lo requiere...