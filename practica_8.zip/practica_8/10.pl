intercalar([], _, []).
intercalar(_, [], []).
intercalar([X|XS], [Y|YS], [X, Y | L]):- intercalar(XS, YS, L).