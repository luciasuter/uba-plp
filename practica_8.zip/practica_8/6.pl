% ?- aplanar([a, [3, b, []], [2]], L).→ L=[a, 3, b, 2]
% ?- aplanar([[1, [2, 3], [a]], [[[]]]], L).→ L=[1, 2, 3, a]

aplanar([], []).
aplanar([ZS|XS], Y):- aplanar(ZS, ZSR), aplanar(XS, XSR), append(ZSR, XSR, Y). %caso primer elemento es una lista
aplanar([X|XS], Y):- not(aplanar(X, _)), aplanar(XS, XSR), append([X], XSR, Y).%caso primer elemento NO es una lista

% [[1], [4,5], [6,7,8]] = [1,4,5,6,7,8]
% [[1,2], [3,4]] = [1,2,3,4]
% [1, [2,3,5], [7,8]] = [1,2,3,5,7,8]