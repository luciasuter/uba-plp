% DIFICIL
% cuadrado semi magico

generarListasQueSumanConYinstLargoN(_, 0, []).
%generarListasQueSumanConYinstLargoN(0, 1, [0]).

generarListasQueSumanConYinstLargoN(X, N, L):- N >0, between(1, X, Y), X1 is X-Y, append([Y], L2, L), N1 is N-1, generarListasQueSumanConYinstLargoN(X1, N1, L2).



