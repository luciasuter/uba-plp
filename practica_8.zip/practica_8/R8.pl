parteQueSuma(_, 0, []).
parteQueSuma([X|XS], S, [X|P]):- SS is S-X, parteQueSuma(XS, SS, P).
parteQueSuma([_|XS], S, P):- parteQueSuma(XS, S, P). 

%  P = [1, 3, 5] ;
%  P = [2, 3, 4] ;
%  P = [2, 3, 4] ;
%  P = [4, 5] ;

% Por que se repite 2,3,4 ?