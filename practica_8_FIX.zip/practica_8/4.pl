juntar([], YS, YS).
juntar([X|XS], YS, [X|ZZS]):- juntar(XS, YS, ZZS).