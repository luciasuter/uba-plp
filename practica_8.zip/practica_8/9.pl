desde(X,X).
desde(X,Y) :- N is X+1, desde(N,Y).

% 1. Cómo deben instanciarse los parámetros para que el predicado funcione? (Es decir, para que no se cuelgue ni produzca un error). Por qué?
% debe instanciarse como desde(+X, -Y).
% de esa forma tenemos todos los valores desde X en adelante 
% hasta que nosotros apretemos "."

% si se instancia desde(-X, +Y) da error por como esta escrito el predicado en la linea 2.
% si se instancian ambos (da true si Y es mayor que x, y luego) se cuelga xq entra en un loop infinito donde siempre entra a esa linea.

% 2. Dar una nueva versión del predicado que funcione con la instanciación desdeReversible(+X,?Y), tal que
% si Y está instanciada, sea verdadero si Y es mayor o igual que X, y si no lo está genere to dos los Y de X en
% adelante.

desde2(X, X). % aca la Y va a unificar con X 
desde2(X, Y):- not(var(Y)), Y > X.
desde2(X, Y):- var(Y), X1 is X+1, desde2(X1, Y). % Y aca logro la recursion
