inorder(nil, []).
inorder(bin(I, V, D), K):- inorder(I, KI), inorder(D, KD), append(KI, [V|KD], K).

arbolConInorder(nil, []).
% arbolConInorder(bin(nil, X, nil), [X]).
% arbolConInorder(A, [X|XS]). 

%hay mas de una opcion con este? porque puede ser arbol con rama izq o der

% insertarOrdenado 2 [1,7,11] = [1,2,7,11]
% 16 [1,7,11] = [1,7,11,16]

insertarOrdenado(X, [], [X]).
insertarOrdenado(X, [Y|YS], [Y|L]):- X > Y, insertarOrdenado(X, YS, L).
insertarOrdenado(X, [Y|YS], L):- X < Y, append([X], [Y|YS], L).


raiz(bin(_, V, _), V).

aBB(nil).
aBB(A):- inorder(A, L), sort(L, L).

aBBInsertar(X, nil, bin(nil, X, nil)).
aBBInsertar(X, A, B):- aBB(A), inorder(A, L),  insertarOrdenado(X, L, LL), arbolConInorder(B, LL).
%me falta hacer arbolConInorder. 
% no es asi porque arbolConInorder me va a devolver muchos resultados y yo solo quiero uno.



% bin(bin(bin(nil, 1, nil), 3, bin(bin(nil, 4, nil), 6, bin(nil, 7, nil))), 8, bin(nil, 10, bin(bin(nil, 13, nil), 14, nil)))

