% hecho el clase
% TRIANGULOS