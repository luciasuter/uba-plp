natural(0).
natural(suc(X)) :- natural(X).
menorOIgual(X, suc(Y)) :- menorOIgual(X, Y).
menorOIgual(X, X) :- natural(X).

%i. Explicar qué sucede al realizar la consulta menorOIgual(0,X). 
% El programa se cuelga porque X va a unificar con suc(Y), se vuelve a llamar a menorOIgual(0, Y) y entra en un ciclo infinito.

%ii. Describir las circunstancias en las que puede colgarse un programa en Prolog. Es decir, ejecutarse infinitamente sin arrojar soluciones.
% se puede colgar un programa en casos donde tenga dos reglas y una llama a la otra y la otra a esta infinitamente

%iii. Corregir la definición de menorOIgual para que funcione adecuadamente.

menorOIgual2(X, X):- natural(X).
menorOIgual2(X, suc(Y)):- menorOIgual2(X, Y).