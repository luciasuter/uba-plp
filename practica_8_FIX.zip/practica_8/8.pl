parteQueSuma(_, 0, []).
parteQueSuma([X|XS], S, [X|P]):- S >0, SS is S-X, parteQueSuma(XS, SS, P).
parteQueSuma([_|XS], S, P):- S >0, parteQueSuma(XS, S, P). 

% parteQueSuma([1,2,3,4,5],9,P).
%  P = [1, 3, 5] ;
%  P = [2, 3, 4] ;
%  P = [2, 3, 4] ;
%  P = [4, 5] ;

% Por que se repite 2,3,4 ?
