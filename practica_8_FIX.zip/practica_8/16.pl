frutal(frutilla).
frutal(banana).
frutal(manzana).
cremoso(banana).
cremoso(americana).
cremoso(frutilla).
cremoso(dulceDeLeche).

leGusta(X) :- frutal(X), cremoso(X).
cucurucho(X,Y) :- leGusta(X), leGusta(Y).

% I.
% cucurucho : X = Frutilla Y = Frutilla
% cucurucho : X = Frutilla Y = Banana
% cucurucho : X = Banana Y = Frutilla
% cucurucho : X = Banana Y = Banana

% II.
% CASO leGusta(X) :- frutal(X), !, cremoso(X). 
% RTA: X = K, K = frutilla. solo mira la primera opcion.

% CASO leGusta(X) :- frutal(X), cremoso(X), !.
% RTA: X = K, K = frutilla. solo mira la primera opcion.

% CASO cucurucho(X,Y) :- leGusta(X), !, leGusta(Y).
% RTAS:
% X = K, K = frutilla ;
% X = frutilla,
% K = banana ;  Solo prueba los casos donde X = Frutilla (la primera opcion)

% CASO cucurucho(X,Y) :- leGusta(X), leGusta(Y), !.
% RTA: X = K, K = frutilla. Solo revisa la primera opcion para x y k.