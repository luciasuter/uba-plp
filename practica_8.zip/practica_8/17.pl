% No entiendo como declarar 
% P(Y) y Q(Y) sin que me de error