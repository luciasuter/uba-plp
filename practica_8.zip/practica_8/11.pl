vacio(nil).
raiz(bin(_, V, _), V).

altura(nil, 0).
altura(bin(I, V, D), A):- A is max(AI AD), altura(I, AI), altura(D, AD).

cantidadDeNodos(nil, 0).
cantidadDeNodos(bin(I, V, D), N):- cantidadDeNodos(I, NI), cantidadDeNodos(D, ND), N is NI + ND + 1.